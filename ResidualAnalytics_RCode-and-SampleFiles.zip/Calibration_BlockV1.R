library(mirt)
library(dplyr)


setwd("Specify://Your/Working_Directory/Path")   #working directory

#Specify output files
output_file <- "Sample_Data_N6k-by-I50"
item_file <- paste(output_file,"_itemParam.csv")
theta_file <- paste(output_file,"_thetaScores.csv")

#Inputs for mirt() analysis
#response file (group index = col(1) )
resp_file <- read.csv("FormsA-C_Groups1-3_MixedFormatNI50_Data.csv")  

#Drop the group variable and limit to studied items (item responses in columns 2:50)
calib_data <- resp_file[,2:51]

#Pull in the group index variable (combined below with theta score estimates)
grp_id <- resp_file[,1]

#Run the mirt() calibration (use itemtype = list(item types by item) if mixed format
model <- mirt(calib_data, 1, itemtype = 'gpcm')

#Score the examinees (max. likelihood in this case)
theta=fscores(model,method="ML")
theta <- theta[,1]

#Create data frames from mirt() objects
all_par <- coef(model,IRTpars=TRUE,simplify=TRUE)
item_par <- as.data.frame(all_par$items)
examinees <- data.frame(theta,grp_id)
examinees$grp_id <- as.factor(grp_id)

#Create the output files for theta and item parameters
write.csv(examinees,file=theta_file)
write.csv(item_par,file=item_file)


