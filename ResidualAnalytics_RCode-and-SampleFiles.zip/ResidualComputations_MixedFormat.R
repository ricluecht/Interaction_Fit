# Load necessary package
library(dplyr)

#Item subset observed scores
compute_raw_subscores <- function(subset, responses) {
  return(rowSums(responses[, subset]))
}

#IRT model-based unidimensional expected response functions (erfs)
#1PL: Rasch 1PL 
erf_1pl <- function (t,b) {prb=1/(1+exp(b-t))
               return(prb)}

#2PL: also use for Rasch 1PL setting a.i=1 for all i and Thissen 1PL with fixed a.i=a
erf_2pl <- function (t,a,b) {prb=1/(1+exp(-a*(t-b)))
               return(prb)}

#3PL: could be generalized to include the 1PL and 2PL
erf_3pl <- function (t,a,b,c) {prb=c+(1-c)/(1+exp(-a*t-b))
               return(prb)}
#PCM
erf_pcm <- function(theta, b_vec) {
  sapply(theta, function(th) {
    k <- sum(!is.na(b_vec))
    scores <- 0:(k - 1)
    logits <- sapply(scores, function(s) sum(th - b_vec[1:s]))
    probs <- exp(logits) / sum(exp(logits))
    sum(scores * probs)
  })
}

#GPCM
erf_gpc <- function(theta, a, b_vec) {
  sapply(theta, function(th) {
    k <- sum(!is.na(b_vec))
    scores <- 0:(k - 1)
    logits <- sapply(scores, function(s) sum(a * (th - b_vec[1:s])))
    probs <- exp(logits) / sum(exp(logits))
    sum(scores * probs)
  })
}
#GRM
erf_grm <- function(t,a,b_vec) {
  b <- na.omit(as.numeric(b_vec[i, ]))
  m <- length(b)
  xv <- 0:m
  P_star <- c(1, 1/(1 + exp(-a * (t - b_vec))), 0)
  # Category probabilities: P_k = P*_k - P*_{k+1}
  P_k <- P_star[1:(m + 1)] - P_star[2:(m + 2)]
  ers <- sum(xv * P_k[1:m])
  return(ers)}

setwd("Specify://Your/Working_Directory/Path")

#Input the item parameters
item_param_file <- "Sample_Data6kby50 _itemParam_wModel.csv"
iparam <- read.csv(file=item_param_file,header=TRUE)
ni <- length(iparam)

#Input the theta estimates
theta_file <- "Sample_Data_N6k-by-I50 _thetaScores.csv"
theta_recs <- read.csv(file=theta_file, header=TRUE)


#Read scored items responses into a matrix
resp_file <- "FormsA-C_Groups1-3_MixedFormatNI50_Data.csv"
resp_recs <- read.csv(file=resp_file,header=TRUE)
rsp <- as.matrix(resp_recs[2:51],ncol=ni)
y_total <- rowSums(rsp,2)

#Assign variables to model, a, bv(matrix) 
#c can be excluded for the 1PL and 2PL models; a is excluded for the 1PL computations
#Specify the columns in iparam containing the b values for all items 
# There is only one column if all items use one or more dichotomous IRT models

b_col <- c(5:8)
m <- length(b_col)
b <- matrix(NA, nrow=ni, ncol=length(b_col))
model <- iparam$model
a <- iparam$a
c <- rep(NA,ni)
b <- as.matrix(iparam[b_col],ncol=m)
# Define item subsets (example: first half and second half)
# Define item subsets (indices)
item_subsets <- list(
   subset1 <- c(1:5,11:20),
   subset2 <- c(6:10,21:30),
   subset3 <- c(31:50))

#theta <- seq(-2,2,.25)

compute_erfs <- function(theta, subset_idx) {
  sapply(theta, function(th) {
    sum(sapply(subset_idx, function(i) {
      mod <- model[i]
      if (mod == "1PL") {
        erf_1pl(th, b[i, 1])
      } else if (mod == "2PL") {
        erf_2pl(th, a[i], b[i, 1])
      } else if (mod == "3PL") {
        erf_3pl(th, a[i], b[i, 1], c[i])
      } else if (mod == "PCM") {
        erf_pcm(th, b[i, ])
      } else if (mod == "GPC") {
        erf_gpc(th, a[i], b[i, ])
      } else if (mod == "GRM") {
        erf_grm(th, a[i], b[i, ])
      } else {
        NA
      }
    }))
  })
}

# Apply to all subsets
tcf_list <- lapply(item_subsets, function(subset_idx) {
  compute_erfs(theta_recs$theta, subset_idx)
})  

# Combine into a data frame
tcf_df <- as.data.frame(do.call(cbind, tcf_list))
names(tcf_df) <-c("tcf1","tcf2","tcf3")

# Compute raw subscores for all subsets
subscore1 <- compute_raw_subscores(subset1, rsp)
subscore2 <- compute_raw_subscores(subset2, rsp)
subscore3 <- compute_raw_subscores(subset3, rsp)

# Compute residuals
residuals1 <- tcf_df$tcf1 - subscore1
residuals2 <- tcf_df$tcf2 - subscore2
residuals3 <- tcf_df$tcf3 - subscore3
# Save results
results <- cbind(theta_recs,y_total,tcf_df,
                 subscore1,subscore2,subscore3,
                 residuals1,residuals2,residuals3)


write.csv(results, "Sample_IRT_ItemSubset_Residuals.csv", row.names = FALSE)

cat("Processing complete! Results saved to 'Sample_IRT_ItemSubset_Residuals.csv'.\n")