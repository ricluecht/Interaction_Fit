library(dplyr)
library(ggplot2)
library(psych)

#Combined data
rm(list=ls())
setwd("Specify://Your/Working_Directory/Path"")

#Specify parameters for the analysis
grp_index <- c(1,2,3)
n_grp <- length(grp_index)
dfg <- n_grp-1
min_count <- 5
zCrit <-2


#Default aesthetics for plot 
glines <- c("dashed","solid","dotdash","twodash","longdash")
gshapes <- c(22,23,21,24,25)
#subset the shapes and line types
glines <- glines[1:n_grp]
gshapes <- gshapes[1:n_grp]

#Data inputs and variable assignments
#Input file
residFile <- "Sample_IRT_ItemSubset_Residuals.csv"
dFileAll <- read.csv(file=residFile,header=TRUE)
dFile <- dFileAll[dFileAll$grp %in% grp_index,]
#Assign key variables to default names and types (grp, ytotal, dv as the subset residual variable )
dFile$grp <- as.factor(dFile$grp_id) 
dFile$ytotal <- dFile$y_total

dv_columns <- c(11,12,13)  #column positions of the dependent residual variable in residFile

for (qd in 1:n_grp) {
    dFile$dv <- dFile[,dv_columns[qd]]  #changes dv for each subset residual

    #dFile$dv <- dFile$residuals2
#dFile$dv <- dFile$residuals3

#Output specifications are subset-specific
ylbl <- paste("Residuals (Item Subset",qd, ")",sep="")
outFile <- paste("SampleOutputs_Residual_",qd,sep="")

#Check for empty cells in the X_Total (y) by Group table and collapse into the lowest score 
tcount=table(dFile$ytotal,dFile$grp)

qualified_y <- dFile %>%
  group_by(ytotal, grp) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(ytotal) %>%
  filter(all(n >= min_count)) %>%
  distinct(ytotal)

# Specify the minimum and maximum total scores (ytotal) 
#yMin <- min(qualified_y$ytotal)
#yMax <- max(qualified_y$ytotal)

# Use the result to filter the original data
dF2 <- dFile %>%
  semi_join(qualified_y, by = "ytotal")

#Check the result 
table(dF2$ytotal,dF2$grp)

#Level 1 analysis to get the grand mean for each value of y
lvl1_stats <- dF2 %>%
  group_by(ytotal) %>%
  summarise(
    GrdMn = mean(dv, na.rm = TRUE),
#    GrdSD = sd(dv, na.rm=TRUE),
    NX=n(),
#    GrdSE = (GrdSD/sqrt(NX))*sqrt(dfg),
    .groups = 'drop'
  )

#Compute MS(residual) for each y score
  lvl1_aov <- lapply(split(dF2, dF2$ytotal), function(i){
    model <- aov(dv ~ grp, data = i)
    aov_table <- summary(model)[[1]]
    ms_res <- aov_table["Residuals","Mean Sq"]
    return(ms_res)
  })

#Create a dataframe and add ytotal values for left_join() to follow
lvl1_MS <- as.data.frame(unlist(lvl1_aov))
lvl1_MS <- as.data.frame(do.call(rbind, lvl1_aov))
lvl1_MS$xt <- rownames(lvl1_MS)
names(lvl1_MS) <- c("MSRes","ytotal")
#combine MS with the ytotal results
lvl1_stats <- cbind(lvl1_stats,lvl1_MS[-2])

#Compute the studentized residuals
lvl2_stats <- dF2 %>%
  group_by(ytotal,grp) %>%
  left_join(lvl1_stats,by="ytotal") %>%
  mutate(MnY=mean(dv),
    SEPooled=sqrt(dfg*(MSRes/NX)),
    Zy=(MnY-GrdMn)/SEPooled) %>%
  ungroup()
  
stat_tbl1 <- describe(lvl2_stats$Zy)
stat_tbl2 <- describeBy(lvl2_stats$Zy,group=lvl2_stats$grp)

#QQ plot to check for normality of the residuals
pznorm <- ggplot(data=lvl2_stats,aes(sample=Zy)) + 
  stat_qq() +
  stat_qq_line(linetype="dashed",color="darkred") +
  labs(x="Theoretical Values",y="Sample Quantiles")

#Create the group x total score data frame & eliminate any results with NA
lvl12_stats <- lvl2_stats %>% 
  group_by(grp,ytotal) %>% 
  summarise(n=n(),mnz=mean(Zy),na.rm=TRUE)

clean_Z_Stats <- na.omit(lvl12_stats)
stat_tbl3 <- describe(clean_Z_Stats$mnz)
stat_tbl4 <- describeBy(clean_Z_Stats$mnz,group=clean_Z_Stats$grp)

#Plot mean(Z) by included total scores with separate aesthetics for each group
plot_zmeans <- ggplot(clean_Z_Stats,aes(x=ytotal,y=mnz,fill=grp,linetype=grp,shape=grp)) + ylim(-5,5) +
  geom_smooth(se=FALSE,color="black") +
  geom_point(size=2.5,aes(shape=grp)) +
  scale_shape_manual(values=gshapes) +
  scale_linetype_manual(values = glines) +
  geom_hline(yintercept=c(-2,2),,linetype="dashed") +
  scale_fill_brewer(palette="Blues") +
  labs(x="Raw Scores",y=ylbl,fill="Groups",linetype="Groups",shape="Groups")

#Count the number of cells where |mean(z)|>=zCrit
flagged_z <- sum(abs(clean_Z_Stats$mnz)>=zCrit)
nXValues <- nrow(clean_Z_Stats)
pct_flagged <- round((flagged_z/nXValues)*100,4)

#Save statistical summaries to a file and create .png graphics files
ggsave(file=paste(outFile,"_MeanZ.png"),plot=plot_zmeans,height=5,width=6,units="in")
ggsave(file=paste(outFile,"_PPPlot.png"),plot=pznorm,height=6,width=6,units="in")
#
#Form quantiles (quintiles in this case) to denote proficiency levels
dF3 <- dFile %>% mutate(quant5 = findInterval(ytotal, 
                                  quantile(ytotal, probs = seq(0, 1, 0.2)),
                                  rightmost.closed = TRUE))

#Check counts and run the two-way anova
qtable <- table(dF3$quant5)
totaov2 <- aov(dv~grp*quant5,data=dF3)

#Some useful analysis results 
sink(paste(outFile,"_Summary_Statistics.txt",sep=""))
cat("ANCOVA Summary Table (covariate=dFile$ytotal)\n")
totaov1 <- aov(dv~ytotal+grp,data=dFile)
print(summary(totaov1),digits=3)  
cat("\n")
cat("2-Way ANOVA Summary Table (check the interaction term)\n")
print(summary(totaov2),digits=3)  
cat("\n")
cat("Descriptives Total Group Statistics (Individual Z Values)\n")
stat_tbl1
cat("\n")
cat("grp-Level Statistics (Individual Z Values)\n")
stat_tbl2
cat("\n")
cat("Descriptives Mean[Z] (All Groups and Total Scores)\n")
stat_tbl3
cat("\n")
cat("Descriptives Mean[Z] by Group\n")
stat_tbl3
cat("\n")
cat("Flagged Mean(Z) Count   = ",flagged_z,"\n")
cat("Total Count of Z Values = ",nXValues,"\n")
cat("Percent flagged         = ",pct_flagged,"%\n")
cat("\n")
cat("Frequency Table of Obs. Scores by Groups (y=rows, columns are group-level counts)")
print(tcount)
sink()
}
#dev.off()
